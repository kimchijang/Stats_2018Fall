%  book_3_45.m

load fly

plot(Temperature,FacetNumber,'o')
xlabel('Temperature (deg C)')
ylabel('Facet Number')
title('Fly')
